package com.thinroot.deb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerApi1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
