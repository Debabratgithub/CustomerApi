package com.thinroot.deb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.thinroot.deb.entity.Customer;
import com.thinroot.deb.exception.CustomerNotFoundException;
import com.thinroot.deb.service.CustomerService;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {

	@Autowired
	private CustomerService service;
	
	@PostMapping("/create")
	public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
//		Integer id=service.createCustomer(customer);
//		String message = "Customer '"+id+"' Added!";
		Customer createCustomer = service.createCustomer(customer);
		return new ResponseEntity<Customer>(createCustomer,HttpStatus.CREATED);
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<Customer>> findAllCostomer() {
		List<Customer> list=service.findAllCustomer();
		return new ResponseEntity<List<Customer>>(list, HttpStatus.OK);
	}
	
	@GetMapping("/find/{id}")
	public ResponseEntity<?> findOneEmployee(@PathVariable Integer id) {
		ResponseEntity<?> resp=null;
		try {
			Customer customer=service.findOneCustomer(id);
			resp=new ResponseEntity<Customer>(customer,HttpStatus.OK);
		}catch (CustomerNotFoundException e) {
			e.printStackTrace();
			resp=new ResponseEntity<String>(e.getMessage(), 
					HttpStatus.NO_CONTENT);
		}
		return resp; 
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteCustomer(@PathVariable Integer id) {
		ResponseEntity<String> resp= null;
		try {
			service.deleteOneCustomer(id);
			resp = new ResponseEntity<String>("Employee Deleted!",HttpStatus.OK);
		}catch (CustomerNotFoundException e) {
			e.printStackTrace();
			throw e;
		}
		return resp;
	}
	
	@PutMapping("/modify/{id}")
	public ResponseEntity<Customer> updateCustomer(@PathVariable Integer id,@RequestBody Customer customer) {
		Customer updateCustomer = service.updateCustomer(id, customer);
		return new ResponseEntity<Customer>(updateCustomer,HttpStatus.CREATED);
	}
}
