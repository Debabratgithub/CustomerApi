package com.thinroot.deb.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thinroot.deb.dao.CustomerRepository;
import com.thinroot.deb.entity.Customer;
import com.thinroot.deb.exception.CustomerNotFoundException;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository repo;
	
	public Customer createCustomer(Customer customer) {
		Customer save = repo.save(customer);
		return save;
	}
	
	public List<Customer> findAllCustomer() {
		List<Customer> list=repo.findAll();
		return list;
	}
	
	public Customer findOneCustomer(int id) {
		Optional<Customer> opt=repo.findById(id);
		return repo.findById(id).orElseThrow(()->new CustomerNotFoundException("Customer is not available") );
	}
	
	public Customer updateCustomer(Integer id, Customer customer) {
		if(id!=null && repo.existsById(id)) {
			return repo.save(customer);
		}else 
			throw new CustomerNotFoundException("Customer '"+id+"'not Exist");
	}
	
	public void deleteOneCustomer(Integer id) {
		repo.delete(findOneCustomer(id));
	}
	
}
