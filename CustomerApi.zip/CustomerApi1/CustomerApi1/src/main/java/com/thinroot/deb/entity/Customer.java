package com.thinroot.deb.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="customerid")
	private Integer cid;
	
	@NotEmpty(message="Username shoudln't be null")
	@Column(name="customername")
	private String cname;
	
	@NotEmpty
	@Column(name="customernumber")
	private Long cnumber;
	
	@NotEmpty
	@Column(name="customeraddress")
	private String caddr;
	
	@Email(message="Invalid email address")
	@Column(name="customeremail")
	private String cemail;

	
}
